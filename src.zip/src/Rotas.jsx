import React from 'react'
import { Switch, Route } from 'react-router-dom'
import HelloWorld from './components/HelloWorld'
import Pagina1 from './pages/Pagina1'
import Pagina2 from './pages/Pagina2'

const Rotas = () => {
    return (
        <div>
            <Switch>
                <Route exact path="/" component={HelloWorld} />
                <Route exact path="/pagina1" component={Pagina1} />
                <Route exact path="/pagina2" component={Pagina2} />
            </Switch>
        </div>
    )
}

export default Rotas
